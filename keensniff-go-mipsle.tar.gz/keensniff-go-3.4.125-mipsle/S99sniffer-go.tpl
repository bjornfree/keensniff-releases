#!/bin/sh
# Entware lifecycle and crash supervision, without Python helpers.
ROOT="__ROOT__"
BIN="$ROOT/bin/keensniff"
CONFIG="$ROOT/config.json"
PIDFILE=/var/run/keensniff-go.pid
SUPFILE="$PIDFILE.supervisor"
LOGFILE=/var/log/sniffer.log
MAX_LOG=5242880
SCRIPT=$(readlink -f "$0")

_daemon_alive() {
    case "${CHILD:-}" in ''|*[!0-9]*|0) return 1;; esac
    kill -0 "$CHILD" 2>/dev/null || return 1
    [ "$(awk '/^State:/{print $2}' "/proc/$CHILD/status" 2>/dev/null)" != Z ] || return 1
    tr '\000' '\n' < "/proc/$CHILD/cmdline" 2>/dev/null | grep -Fxq "$CONFIG" || return 1
}
_supervisor_alive() {
    case "${SUP:-}" in ''|*[!0-9]*|0) return 1;; esac
    kill -0 "$SUP" 2>/dev/null || return 1
    tr '\000' '\n' < "/proc/$SUP/cmdline" 2>/dev/null | grep -Fxq "$SCRIPT" || return 1
    tr '\000' '\n' < "/proc/$SUP/cmdline" 2>/dev/null | grep -Fxq supervise || return 1
    tr '\000' '\n' < "/proc/$SUP/cmdline" 2>/dev/null | grep -Fxq "$TOKEN"
}
_stop_child() {
    case "${CHILD:-}" in ''|*[!0-9]*|0) return 0;; esac
    kill -0 "$CHILD" 2>/dev/null || return 0
    kill -TERM "$CHILD" 2>/dev/null || return 0
    N=0
    while kill -0 "$CHILD" 2>/dev/null; do
        N=$((N + 1))
        # Allow the 15-second firewall cleanup and worker shutdown to finish.
        if [ "$N" -gt 35 ]; then
            kill -9 "$CHILD" 2>/dev/null
            break
        fi
        sleep 1
    done
}
_rotate_log() {
    if [ -f "$LOGFILE" ] && [ "$(wc -c < "$LOGFILE")" -gt "$MAX_LOG" ]; then
        mv -f "$LOGFILE" "${LOGFILE}.1"
    fi
}
supervise() {
    TOKEN=$1
    CHILD=
    STOPPING=0
    # Defer termination until CHILD has been published, including a signal
    # arriving between fork and assignment of $!.
    trap 'STOPPING=1; [ -n "$CHILD" ] && kill -TERM "$CHILD" 2>/dev/null' HUP INT TERM
    while [ "$STOPPING" = 0 ] && [ -f "$TOKEN" ]; do
        _rotate_log
        ST=$(date +%s)
        env -u LD_LIBRARY_PATH -u LD_PRELOAD PATH=/opt/bin:/opt/sbin:$PATH "$BIN" -daemon-config "$CONFIG" >>"$LOGFILE" 2>&1 &
        CHILD=$!
        echo "$CHILD" > "$PIDFILE"
        if [ "$STOPPING" = 0 ] && [ -f "$TOKEN" ]; then wait "$CHILD"; fi
        [ "$STOPPING" = 0 ] && [ -f "$TOKEN" ] || break
        EL=$(( $(date +%s) - ST ))
        [ "$EL" -lt 10 ] && D=15 || D=3
        echo "[$(date)] [watchdog] exit uptime=${EL}s restart in ${D}s" >>"$LOGFILE"
        sleep "$D"
    done
    _stop_child
    _cleanup_orphans
}
_cleanup_orphans() {
    for pid in $(pidof keensniff 2>/dev/null); do
        kill -9 "$pid" 2>/dev/null || true
    done
}
start() {
    CHILD=$(cat "$PIDFILE" 2>/dev/null)
    SUP=$(awk 'NR==1{print $1}' "$SUPFILE" 2>/dev/null)
    TOKEN=$(awk 'NR==1{print $2}' "$SUPFILE" 2>/dev/null)
    if _supervisor_alive; then echo "Already supervised (PID $SUP)"; return 0; fi
    _cleanup_orphans
    [ -x "$BIN" ] && [ -r "$CONFIG" ] || { echo "Missing $BIN or $CONFIG" >&2; return 1; }
    WAITED=0
    while [ ! -S /var/run/ndm.core.socket ] && [ "$WAITED" -lt 15 ]; do sleep 1; WAITED=$((WAITED + 1)); done
    TOKEN=$(mktemp "$PIDFILE.run.XXXXXX") || return 1
    (trap '' HUP; exec "$SCRIPT" supervise "$TOKEN") >/dev/null 2>&1 </dev/null &
    SUP=$!
    printf '%s %s\n' "$SUP" "$TOKEN" > "$SUPFILE"
    WAIT_START=0
    while [ "$WAIT_START" -lt 8 ]; do
        sleep 1
        WAIT_START=$((WAIT_START + 1))
        CHILD=$(cat "$PIDFILE" 2>/dev/null)
        if _supervisor_alive && _daemon_alive; then
            break
        fi
    done
    _supervisor_alive && _daemon_alive || { stop; echo 'Go daemon failed startup' >&2; return 1; }
    echo "Started (PID $CHILD)"
}
stop() {
    SUP=$(awk 'NR==1{print $1}' "$SUPFILE" 2>/dev/null)
    TOKEN=$(awk 'NR==1{print $2}' "$SUPFILE" 2>/dev/null)
    case "$TOKEN" in "$PIDFILE".run.*) rm -f "$TOKEN";; esac
    if _supervisor_alive; then
        kill -TERM "$SUP" || return 1
        N=0
        while _supervisor_alive; do
            N=$((N + 1)); [ "$N" -le 35 ] || { kill -9 "$SUP" 2>/dev/null; break; }
            sleep 1
        done
    fi
    CHILD=$(cat "$PIDFILE" 2>/dev/null)
    _stop_child || return 1
    _cleanup_orphans
    rm -f "$PIDFILE" "$SUPFILE"
    echo Stopped
}

case "${1:-}" in supervise) supervise "$2"; exit;; esac
LOCK="$PIDFILE.lock"
if ! mkdir "$LOCK" 2>/dev/null; then
    LOCKPID=$(cat "$LOCK/pid" 2>/dev/null || true)
    if [ -n "$LOCKPID" ] && kill -0 "$LOCKPID" 2>/dev/null; then
        echo 'Go lifecycle operation already running' >&2; exit 1
    fi
    rm -rf "$LOCK"
    if ! mkdir "$LOCK" 2>/dev/null; then
        echo 'Go lifecycle operation already running' >&2; exit 1
    fi
fi
echo "$$" > "$LOCK/pid"
trap 'rm -rf "$LOCK" 2>/dev/null || true' 0 INT TERM HUP
case "${1:-}" in
    start) start;;
    stop) stop;;
    restart) stop && start;;
    status) CHILD=$(cat "$PIDFILE" 2>/dev/null); _daemon_alive && echo "Running (PID $CHILD)";;
    *) echo "Usage: $0 {start|stop|restart|status}" >&2; exit 2;;
esac
