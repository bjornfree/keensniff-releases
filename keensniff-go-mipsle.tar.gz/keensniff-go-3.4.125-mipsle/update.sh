#!/bin/sh
# ==============================================================================
# KeenSniff (Go) — Скрипт бесшовного обновления по воздуху (OTA)
# Запускается бэкендом из веб-интерфейса или вручную: sh /opt/keensniff-go/update.sh
# ==============================================================================
set -eu

ROOT="${KEENSNIFF_ROOT:-/opt/keensniff-go}"
INIT="${KEENSNIFF_INIT:-/opt/etc/init.d/S99sniffer-go}"
STATUS_FILE="${GO_UPDATE_STATUS:-$ROOT/state/update-status.json}"
REPO="bjornfree/keensniff-releases"
RELEASE_URL="${KEENSNIFF_RELEASE_URL:-https://github.com/${REPO}/releases/latest/download}"
# Mirror: the same archives on a single-commit branch, served by raw.githubusercontent.com.
MIRROR_URL="${KEENSNIFF_MIRROR_URL:-https://raw.githubusercontent.com/${REPO}/downloads}"

# Set once the lock is held: a manual run (deploy-router.sh, SSH) also writes
# the log the panel shows. Backend runs already redirect stdout into it.
LOG_FILE=""

log() {
    printf "[keensniff] %s\n" "$*"
    [ -z "$LOG_FILE" ] || printf "[keensniff] %s\n" "$*" >> "$LOG_FILE"
}

# Modes: no argument installs the latest release, a path installs that local
# archive, --rollback swaps back to the version kept by the last update.
MODE="update"
if [ "${1:-}" = "--rollback" ]; then
    MODE="rollback"
    shift
fi

# A requested local package must never fall back to an unrelated latest release.
if [ -n "${1:-}" ] && [ ! -f "$1" ]; then
    log "error: Локальный архив не найден"
    exit 1
fi

LOCK_DIR="${KEENSNIFF_UPDATE_LOCK:-/var/run/keensniff-update.lock}"
if ! mkdir "$LOCK_DIR" 2>/dev/null; then
    if [ -f "$LOCK_DIR/pid" ]; then
        old_pid=$(cat "$LOCK_DIR/pid" 2>/dev/null || true)
        if [ -n "$old_pid" ] && kill -0 "$old_pid" 2>/dev/null; then
            log "error: Процесс обновления уже запущен (PID $old_pid)"
            exit 1
        fi
    fi
    rm -rf "$LOCK_DIR" 2>/dev/null || true
    if ! mkdir "$LOCK_DIR" 2>/dev/null; then
        log "error: Не удалось захватить блокировку обновления"
        exit 1
    fi
fi
echo "$$" > "$LOCK_DIR/pid"

STARTED_AT=$(date +%s)
# Previous version kept after a successful update; --rollback swaps it back.
PREV_DIR="$ROOT/.previous"
CANCELLABLE=1
DL_PID=""
TMP_DIR=""
FINISHED=0

# Writes the in-progress state; the backend reads it for the panel.
set_status() {
    cat <<EOF > "$STATUS_FILE.tmp"
{"running": true, "status": "$1", "mode": "$MODE", "applied": false, "cancellable": $( [ "$CANCELLABLE" = 1 ] && echo true || echo false ), "pid": $$, "started_at": $STARTED_AT}
EOF
    mv -f "$STATUS_FILE.tmp" "$STATUS_FILE"
}

report() {
    status="$1"
    err="${2:-}"
    FINISHED=1
    cat <<EOF > "$STATUS_FILE.tmp"
{"running": false, "status": "$status", "mode": "$MODE", "error": "$err", "applied": $( [ "$status" = "completed" ] && echo true || echo false ), "started_at": $STARTED_AT, "finished_at": $(date +%s)}
EOF
    mv -f "$STATUS_FILE.tmp" "$STATUS_FILE"
}

cleanup() {
    [ -z "$DL_PID" ] || kill "$DL_PID" 2>/dev/null || true
    # Any exit without a final report (a crash, a kill) must not leave the
    # panel showing a running update forever.
    [ "$FINISHED" = 1 ] || report "failed" "Обновление прервано"
    rm -rf "$LOCK_DIR" "$TMP_DIR" 2>/dev/null || true
}

# Cancel (SIGTERM from the panel) is honoured until files start being replaced;
# after that the update runs to the end or rolls back on its own.
on_signal() {
    if [ "$CANCELLABLE" = 1 ]; then
        [ -z "$DL_PID" ] || kill "$DL_PID" 2>/dev/null || true
        DL_PID=""
        log "Обновление отменено. Текущая версия не изменялась."
        report "cancelled" "Обновление отменено"
        exit 130
    fi
    log "Отмена недоступна: файлы уже устанавливаются, дождитесь завершения"
}
trap cleanup EXIT
trap on_signal HUP INT TERM

mkdir -p "$ROOT/state"
if [ -z "${GO_UPDATE_STATUS:-}" ]; then
    LOG_FILE="$ROOT/state/update.log"
    : > "$LOG_FILE"
fi

# Copies the installed files into a flat directory.
save_current() {
    rm -rf "$1" && mkdir -p "$1" || return 1
    [ ! -f "$ROOT/bin/keensniff" ] || cp -p "$ROOT/bin/keensniff" "$1/" || return 1
    [ ! -f "$ROOT/bin/import-config" ] || cp -p "$ROOT/bin/import-config" "$1/" || return 1
    [ ! -d "$ROOT/static" ] || cp -Rp "$ROOT/static" "$1/" || return 1
    [ ! -f "$ROOT/VERSION" ] || cp -p "$ROOT/VERSION" "$1/" || return 1
    [ ! -f "$INIT" ] || cp -p "$INIT" "$1/init"
}

# Installs files from a flat directory made by save_current.
restore_from() {
    if [ -f "$1/keensniff" ]; then
        cp -p "$1/keensniff" "$ROOT/bin/keensniff.new" || return 1
        mv -f "$ROOT/bin/keensniff.new" "$ROOT/bin/keensniff" || return 1
    fi
    if [ -f "$1/import-config" ]; then
        cp -p "$1/import-config" "$ROOT/bin/import-config.new" || return 1
        mv -f "$ROOT/bin/import-config.new" "$ROOT/bin/import-config" || return 1
    fi
    if [ -d "$1/static" ]; then
        rm -rf "$ROOT/static.new" || return 1
        cp -Rp "$1/static" "$ROOT/static.new" || return 1
        rm -rf "$ROOT/static" || return 1
        mv "$ROOT/static.new" "$ROOT/static" || return 1
    fi
    [ ! -f "$1/VERSION" ] || cp -p "$1/VERSION" "$ROOT/VERSION" || return 1
    if [ -f "$1/init" ] && ! cmp -s "$1/init" "$INIT"; then
        cp -p "$1/init" "$INIT.new.$$" && mv -f "$INIT.new.$$" "$INIT" || return 1
    fi
}

# Restarts the service and waits up to 30 s for its health endpoint.
restart_healthy() {
    [ -x "$INIT" ] || return 0
    "$INIT" restart >/dev/null 2>&1 || return 1
    attempts=0
    while [ "$attempts" -lt 30 ]; do
        attempts=$((attempts + 1))
        sleep 1
        if command -v curl >/dev/null 2>&1; then
            if curl -fsS -m 2 http://127.0.0.1:8080/api/healthz >/dev/null 2>&1 || curl -fsS -m 2 http://127.0.0.1:18080/api/healthz >/dev/null 2>&1; then
                return 0
            fi
        elif command -v wget >/dev/null 2>&1; then
            if wget -q -T 2 -O /dev/null http://127.0.0.1:8080/api/healthz >/dev/null 2>&1 || wget -q -T 2 -O /dev/null http://127.0.0.1:18080/api/healthz >/dev/null 2>&1; then
                return 0
            fi
        fi
    done
    return 1
}

# Replaces the installed files with $2 (a flat directory), keeping a copy of
# the current ones; on a failed health check puts the copy back.
switch_to() {
    label="$1"
    src="$2"
    backup="$ROOT/.rollback_backup"
    CANCELLABLE=0
    set_status "installing"
    log "Сохранение текущей версии для отката..."
    save_current "$backup" || return 1
    log "Установка файлов: $label..."
    if restore_from "$src" && {
        log "Перезапуск службы KeenSniff..."
        restart_healthy
    }; then
        # Reinstalling the same version must not replace the older one kept
        # for rollback with a copy of itself.
        if [ -d "$PREV_DIR" ] && [ "$(cat "$backup/VERSION" 2>/dev/null)" = "$(cat "$src/VERSION" 2>/dev/null)" ]; then
            rm -rf "$backup"
        else
            rm -rf "$PREV_DIR"
            mv "$backup" "$PREV_DIR"
        fi
        return 0
    fi
    log "error: Служба не ответила на health-чек. Запуск отката..."
    if ! restore_from "$backup"; then
        log "error: Не удалось восстановить предыдущие файлы из $backup"
        return 1
    fi
    "$INIT" restart >/dev/null 2>&1 || true
    rm -rf "$backup"
    log "Откат завершён. Предыдущая версия восстановлена."
    return 1
}

if [ "$MODE" = "rollback" ]; then
    set_status "installing"
    log "Откат KeenSniff на предыдущую версию..."
    if [ ! -f "$PREV_DIR/keensniff" ]; then
        log "error: Предыдущая версия не сохранена"
        report "failed" "Нет сохранённой предыдущей версии"
        exit 1
    fi
    # switch_to replaces $PREV_DIR, so install from a copy.
    TMP_DIR=$(mktemp -d "$ROOT/.keensniff-ota.XXXXXX")
    cp -Rp "$PREV_DIR/." "$TMP_DIR/"
    if ! switch_to "версия $(cat "$TMP_DIR/VERSION" 2>/dev/null || echo предыдущая)" "$TMP_DIR"; then
        report "failed" "Сбой запуска предыдущей версии, оставлена текущая"
        exit 1
    fi
    log "✓ Откат завершён успешно!"
    report "completed" ""
    exit 0
fi

set_status "downloading"
log "Запуск процесса бесшовного OTA-обновления KeenSniff..."

# 1. Определение архитектуры CPU
ARCH=""
if command -v opkg >/dev/null 2>&1; then
    case "$(opkg print-architecture 2>/dev/null | awk '/_kn/{print $2; exit}')" in
        aarch64*) ARCH="arm64" ;;
        mipsel*)  ARCH="mipsle" ;;
        mips*)    ARCH="mips" ;;
        arm*)     ARCH="arm" ;;
    esac
fi
if [ -z "$ARCH" ]; then
    case "$(uname -m 2>/dev/null)" in
        aarch64*|arm64*) ARCH="arm64" ;;
        arm*)            ARCH="arm" ;;
        mips*)
            if [ -f /bin/busybox ]; then
                endian=$(dd if=/bin/busybox bs=1 skip=5 count=1 2>/dev/null | od -An -tu1 2>/dev/null | tr -d ' ')
                if [ "$endian" = "2" ]; then ARCH="mips"; else ARCH="mipsle"; fi
            else
                ARCH="mipsle"
            fi
            ;;
    esac
fi
[ -n "$ARCH" ] || ARCH="arm64"
log "Архитектура процессора: $ARCH"

# 2. Скачивание пакета обновления
# Keep the compressed and extracted package off the router's RAM-backed /tmp.
if ! TMP_DIR=$(mktemp -d "$ROOT/.keensniff-ota.XXXXXX"); then
    log "error: Не удалось создать рабочий каталог на накопителе"
    report "failed" "Не удалось создать рабочий каталог на накопителе"
    exit 1
fi
TARBALL="$TMP_DIR/keensniff-go-${ARCH}.tar.gz"

# Resumable download. A lossy uplink drops long transfers, so continue from the
# received offset instead of restarting, and give up only on a stalled link
# (under 1 KB/s for 45 s), not after a fixed total time.
fetch_resume() {
    local url="$1" out="$2" n=0
    rm -f "$out"
    while [ "$n" -lt 6 ]; do
        n=$((n + 1))
        # Run in the background: a trapped signal interrupts `wait` at once,
        # while a foreground child would delay the cancel until it exits.
        if command -v curl >/dev/null 2>&1; then
            curl -fSL --connect-timeout 15 --speed-limit 1024 --speed-time 45 -C - "$url" -o "$out" 2>/dev/null &
        elif command -v wget >/dev/null 2>&1; then
            wget -q -c -T 45 -O "$out" "$url" 2>/dev/null &
        else
            return 1
        fi
        DL_PID=$!
        if wait "$DL_PID" && [ -s "$out" ]; then
            DL_PID=""
            return 0
        fi
        DL_PID=""
        sleep 2
    done
    return 1
}

# Checks the archive against the .sha256 published next to it. Without
# sha256sum or a reachable checksum file, tar's gzip CRC is the remaining check.
verify_sha256() {
    local file="$1" sum_url="$2" want got
    command -v sha256sum >/dev/null 2>&1 || return 0
    fetch_resume "$sum_url" "$file.sha256" || return 0
    want=$(awk '{print $1; exit}' "$file.sha256")
    got=$(sha256sum "$file" | awk '{print $1}')
    rm -f "$file.sha256"
    [ -n "$want" ] && [ "$want" = "$got" ]
}

# Tries each source in order: GitHub Releases, then the mirror branch.
fetch_from_sources() {
    local name="$1" dest="$2" base
    for base in "$RELEASE_URL" "$MIRROR_URL"; do
        if fetch_resume "$base/$name" "$dest"; then
            if verify_sha256 "$dest" "$base/$name.sha256"; then
                return 0
            fi
            rm -f "$dest"
        fi
    done
    return 1
}

if [ -n "${1:-}" ] && [ -f "$1" ]; then
    log "Локальный пакет: $1"
    cp "$1" "$TARBALL"
elif ! { log "Скачивание пакета обновления ($ARCH)..."; fetch_from_sources "keensniff-go-${ARCH}.tar.gz" "$TARBALL"; }; then
    log "error: Не удалось скачать архив обновления ни с GitHub Releases, ни с зеркала"
    report "failed" "Не удалось скачать архив обновления"
    exit 1
fi

# 3. Распаковка
set_status "verifying"
log "Распаковка и проверка целостности архива..."
EXTRACT="$TMP_DIR/extract"
mkdir -p "$EXTRACT"
if ! tar -xzf "$TARBALL" -C "$EXTRACT"; then
    log "error: Повреждённый архив tar.gz"
    report "failed" "Ошибка распаковки архива"
    exit 1
fi

SRC=$(ls -d "$EXTRACT"/keensniff-go-* 2>/dev/null | head -n 1 || true)
if [ -z "$SRC" ] || [ ! -x "$SRC/bin/keensniff" ]; then
    log "error: В архиве отсутствует исполняемый файл bin/keensniff"
    report "failed" "Некорректная структура архива"
    exit 1
fi

# 4. Проверка совместимости бинарника с CPU
log "Проверка бинарника на совместимость с архитектурой CPU..."
if ! "$SRC/bin/keensniff" -h >/dev/null 2>&1; then
    log "error: Бинарник несовместим с текущим процессором роутера"
    report "failed" "Бинарник обновления не запустился на CPU"
    exit 1
fi

# 5. Установка: package layout -> flat layout used by switch_to.
NEW="$TMP_DIR/new"
mkdir -p "$NEW"
cp -p "$SRC/bin/keensniff" "$NEW/keensniff" && chmod 755 "$NEW/keensniff"
if [ -f "$SRC/bin/import-config" ]; then
    cp -p "$SRC/bin/import-config" "$NEW/import-config" && chmod 755 "$NEW/import-config"
fi
# Keep asset/gzip mtimes aligned so the server accepts precompressed files.
[ ! -d "$SRC/static" ] || cp -pR "$SRC/static" "$NEW/static"
[ ! -f "$SRC/VERSION" ] || cp -p "$SRC/VERSION" "$NEW/VERSION"
if [ -x "$INIT" ] && [ -f "$SRC/S99sniffer-go.tpl" ]; then
    sed "s#__ROOT__#$ROOT#" "$SRC/S99sniffer-go.tpl" > "$NEW/init"
    chmod 755 "$NEW/init"
    sh -n "$NEW/init"
fi

if ! switch_to "версия $(cat "$NEW/VERSION" 2>/dev/null || echo новая)" "$NEW"; then
    report "failed" "Сбой запуска новой версии, выполнен откат"
    exit 1
fi

if [ -f "$SRC/update.sh" ]; then
    # The running shell may still be reading the old updater.
    cp "$SRC/update.sh" "$TMP_DIR/update.sh" &&
        chmod 755 "$TMP_DIR/update.sh" &&
        mv -f "$TMP_DIR/update.sh" "$ROOT/update.sh"
fi
log "✓ Обновление завершено успешно!"
report "completed" ""
exit 0
