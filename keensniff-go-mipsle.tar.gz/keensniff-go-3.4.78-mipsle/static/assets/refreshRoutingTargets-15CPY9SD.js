async function e(s,a){const t=await s(),r=Array.isArray(t)?t:Object.values(t);return a(r),r}export{e as refreshRoutingTargets};
