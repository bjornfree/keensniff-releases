const CACHE_PREFIX = 'keensniff-';

self.addEventListener('install', (event) => {
    self.skipWaiting();
});

self.addEventListener('activate', (event) => {
    event.waitUntil((async () => {
        if (self.caches) {
            const names = await caches.keys();
            await Promise.all(
                names
                    .filter((name) => name.startsWith(CACHE_PREFIX))
                    .map((name) => caches.delete(name))
            );
        }
        await self.clients.claim();
    })());
});

self.addEventListener('fetch', (event) => {
    event.respondWith(fetch(event.request));
});
