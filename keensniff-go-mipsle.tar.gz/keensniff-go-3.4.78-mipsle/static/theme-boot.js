(function () {
    var themeMode = "auto";
    var theme = "light";

    // Истина о выбранной теме живёт в persisted-сторе UI; ключ themeMode —
    // его дубль, который пишет setTheme. Читаем стор первым: если ключи
    // разойдутся (миграция версии стора, ручная чистка), boot покрасит бар
    // по одному значению, а React отрисует страницу по другому.
    try {
        var raw = localStorage.getItem("keen-sniffer-ui");
        var stored = raw ? (JSON.parse(raw).state || {}).theme : null;
        if (stored !== "light" && stored !== "dark" && stored !== "auto") {
            stored = localStorage.getItem("themeMode");
        }
        if (stored === "light" || stored === "dark" || stored === "auto") {
            themeMode = stored;
        }
        if (themeMode === "dark") {
            theme = "dark";
        } else if (themeMode === "light") {
            theme = "light";
        } else if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) {
            theme = "dark";
        }
    } catch (_) {}

    document.documentElement.dataset.theme = theme;
    document.documentElement.dataset.themeMode = themeMode;
    document.documentElement.style.colorScheme = theme;
    var schemeMeta = document.querySelector('meta[name="color-scheme"]');
    if (schemeMeta) schemeMeta.setAttribute("content", theme);

    var targetColor = theme === "dark" ? "#12161c" : "#f1f3f6";
    document.documentElement.style.backgroundColor = targetColor;
    // Полосу вне вьюпорта (в fullscreen там системный бар) Chrome красит
    // фоном документа. Ставим цвет и на body: одного html недостаточно —
    // фон body приходит из CSS-переменной, а она доезжает только со стилями.
    if (document.body) {
        document.body.style.backgroundColor = targetColor;
    } else {
        document.addEventListener("DOMContentLoaded", function () {
            document.body.style.backgroundColor = targetColor;
        });
    }

    var appleMeta = document.querySelector('meta[name="apple-mobile-web-app-status-bar-style"]');
    if (appleMeta) {
        appleMeta.setAttribute("content", theme === "dark" ? "black" : "default");
    }

    // Android PWA / WebAPK / Chrome:
    // Ни в коем случае НЕ удаляем <meta name="theme-color"> из DOM!
    // Удаление DOM-узлов ломает C++ StatusBarColorController в Android WebAPK,
    // из-за чего статус-бар залипает на начальном светлом фоне, а системные иконки
    // становятся белыми (белое на белом — нечитаемо).
    // Вместо удаления синхронизируем атрибуты content всех тегов:
    var lightColor = themeMode === "dark" ? "#12161c" : "#f1f3f6";
    var darkColor = themeMode === "light" ? "#f1f3f6" : "#12161c";

    var lightMeta = document.getElementById("themeColorLight") || document.querySelector('meta[name="theme-color"][media*="light"]');
    if (lightMeta) {
        lightMeta.setAttribute("content", lightColor);
    }
    var darkMeta = document.getElementById("themeColorDark") || document.querySelector('meta[name="theme-color"][media*="dark"]');
    if (darkMeta) {
        darkMeta.setAttribute("content", darkColor);
    }

    var fallbackMeta = document.getElementById("themeColorMeta");
    if (!fallbackMeta) {
        fallbackMeta = document.createElement("meta");
        fallbackMeta.id = "themeColorMeta";
        fallbackMeta.name = "theme-color";
        document.head.appendChild(fallbackMeta);
    }
    fallbackMeta.setAttribute("content", targetColor);
})();
