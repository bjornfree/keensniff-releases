#!/bin/sh
# NDM hook для Go-версии: одна строка в spool и выход (без fork и сети).
# Каталог создаёт демон при старте и удаляет при остановке; >> каталог не создаёт,
# поэтому остановленный демон строк не копит. Ставится симлинками в
# /opt/etc/ndm/{ifcreated,ifdestroyed,ifipchanged,iflayerchanged,neighbour,wan,netfilter,...}.d/
d=${0%/*}; d=${d%.d}
common_name=$(printf '%s' "${common_name}" | tr -c 'A-Za-z0-9._@-' '_')
echo "type=${d##*/}&id=${id}&system_name=${system_name}&layer=${layer}&level=${level}&address=${address}&up=${up}&connected=${connected}&ip=${ip}&mac=${mac}&state=${state}&interface=${interface}&dev=${dev}&common_name=${common_name}" \
    2>/dev/null >> /var/run/keensniff/hooks/ndm-hooks
exit 0
